package com.infinitumcode.mymovieapp.data

enum class Status {
    SUCCESS,
    ERROR,
}