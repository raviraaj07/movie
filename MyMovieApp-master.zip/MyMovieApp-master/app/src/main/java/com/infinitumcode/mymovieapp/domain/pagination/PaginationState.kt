package com.infinitumcode.mymovieapp.domain.pagination

enum class PaginationState {
    DONE, EMPTY, LOADING, ERROR
}